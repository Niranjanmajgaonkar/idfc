<?php
	$db = simplexml_load_file("Slip27_b_book.xml") or die("File Cannot Open");

	echo "<table border = 1>";

	echo "<tr>";
		echo "<th> Code </th>";
		echo "<th> Name </th>";
		echo "<th> Author </th>";
		echo "<th> Year </th>";
		echo "<th> Price </th>";
	echo "</tr>";
	foreach($db->book as $b)
	{
		echo "<tr>";
			echo "<td>".$b->code."</td>";
			echo "<td>".$b->name."</td>";
			echo "<td>".$b->author."</td>";
			echo "<td>".$b->year."</td>";
			echo "<td>".$b->price."</td>";
		echo "</tr>";
	}
	echo "</table>";
?>