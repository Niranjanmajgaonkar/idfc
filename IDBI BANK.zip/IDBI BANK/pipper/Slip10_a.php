<?php
	class Exp
	{
		public $a = "abc";
	
		private $b = "pqr";
		
		public function PublicMethod()
		{
			echo "<br> Public Method<br>";
		}
		
		public function PrivateMethod()
		{
			echo "<br> Private Method<br>";
		}
	}
	
	$obj = new Exp();
	
	if(is_object($obj))
	{
		echo "<br> Obj is an Object";
	}
	else
	{
		echo "<br> Obj is not an Object";
	}
	
	echo "<br>";
	
	$classname = get_class($obj);
	echo "<br> Class name is : ".$classname;
	
	echo "<br>";
	
	if(method_exists($obj,'PublicMethod'))
	{
		echo "<br> PublicMethod() Method is exists in class Exp";
	}
	else
	{
		echo "<br> PublicMethod() Method is not exists in class Exp";
	}
?>