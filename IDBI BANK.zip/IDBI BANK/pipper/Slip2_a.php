<?php
	class vehicle
	{
		public $mileage,$pace,$speed,$name;
		
		public function getData($name)
		{
			$this->name=$name;
		}
		public function putData()
		{
			echo $this->name."".$this->mileage."".$this->pace."".$this->speed;
		}
	}
	class twowheeler extends vehicle
	{
		//
	}
	$car=new vehicle();

	echo "<br> Declared Classes : ";
	$cars=get_declared_classes();
	foreach($cars as $clas)
	{
		echo "<br>".$clas;
	}
	echo "<br> Class Methods : ";
	print_r(get_class_methods('vehicle'));
		
	echo "<br> Class Variables : ";
	print_r(get_class_vars('vehicle'));
?>