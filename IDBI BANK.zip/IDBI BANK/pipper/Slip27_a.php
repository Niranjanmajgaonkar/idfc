<?php
		$no = $_GET['no'];

		$factorial = 1;

		for($x=1; $x<=$no; $x++)
		{
			$factorial = $factorial*$x;
		}

		echo "<br> Factorial of $no is $factorial";
	
?>