<html>
<head><title> Stack </title>
</head>
<body>
		<form method = "get" action = "">
				Enter Element 
					<input type = "text" name = "ele"><br>
					
				<input type = "radio" name = "choice" value = "1">Insert <br><br>
				<input type = "radio" name = "choice" value = "2">Delete <br><br>
				<input type = "radio" name = "choice" value = "3">Display <br><br>
				
				<input type = "submit" name = "submit" value = "submit">
		</form>
</body>
</html>

<?php
		
		if(isset($_GET['submit']))
		{
				$ch = $_GET['choice'];
				$arr = array(10,20,30,40,50);
				
				switch($ch)
				{
						case 1: array_push($arr,$_GET['ele']);
									print_r($arr);
									break;
						case 2: echo array_pop($arr);
									print_r($arr);
									break;
						case 3: print_r($arr);
				}
		}
?>