<html>
		<body>
				<form method = "get">
						<input type = "radio" name = "op" value = "Triangle" >Triangle<br><br>
						<input type = "radio" name = "op" value = "Square">Square<br><br>
						<input type = "radio" name = "op" value = "Circle">Circle<br><br>
					
						<input type = "submit" name = "submit" value = "Display">
				</form>
		</body>
</html>

<?php

	if(isset($_GET['submit']))
	{	
		$op = $_GET['op'];

		abstract class Shape
		{	
				abstract function area();
		}
		
		class Triangle extends Shape
		{
				var $b,$h;
				
				function __construct($b,$h)
				{
					$this->b=$b;
					$this->h=$h;
				}
				
				function area()
				{
					echo "<br> Triangle Area is : ".(($this->b*$this->h)/2);
				}
		}
		
		class Square extends Shape
		{
				var $s;
				
				function __construct($s)
				{
					$this->s=$s;
				}
				
				function area()
				{
					echo "<br> Square Area is : ".($this->s*$this->s);
				}
		}
		
		class Circle extends Shape
		{
				var $r;
				
				function __construct($r)
				{
					$this->r=$r;
				}
				
				function area()
				{
					echo "<br> Circle Area is : ".(3.14*$this->r*$this->r);
				}
		}
		
		$t = new Triangle(2,4);
		$sq = new Square(5);
		$c = new Circle(3);
		
		if($op=="Triangle")
		{
			$t->area();
		}
		else if($op=="Square")
		{
			$sq->area();
		}
		else if($op=="Circle")
		{
			$c->area();
		}
	}	
?>