<?php

	$ct = $_GET["ct"]; 
	$hint = "";

	$cities[]="Nashik";
	$cities[]="Pune";
	$cities[]="Mumbai";
	$cities[]="Delhi";
	$cities[]="Sambhaji Nagar";
	$cities[]="Latur";
	$cities[]="Deola";
	$cities[]="Kalwan";
	$cities[]="Satana";
	$cities[]="Malegaon";
	$cities[]="Nagpur";
	$cities[]="Vani";
	$cities[]="Nanduri";
	$cities[]="Kolhapur";
	$cities[]="Satara";
	$cities[]="Sangali";
	$cities[]="Solapur";
	$cities[]="Usmanabaad";
	$cities[]="Dindori";

	if ($ct != "") 
	{
		$len = strlen($ct);

		foreach($cities as $name) 
		{
			if (stristr($ct, substr($name,0,$len))) 
			{
				$hint = $hint." ".$name; 
			}
		}
	}
	
	if($hint == "")
	{
		echo "no suggestion";
	}
	else
	{
		echo $hint;
	}

?>