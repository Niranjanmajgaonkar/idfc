<html>
<head>
	<title>Teacher</title>
</head>
	<body>
	<form action="#" method="post"><br>
		Enter Teacher ID :
		<input type="text" name="tid" value=""><br><br>
		Enter Name :
		<input type="text" name="tname" value=""><br><br>
		Enter Address :
		<input type="text" name="addr" value=""><br><br>
		Enter Subject :
		<input type="text" name="sub" value=""><br><br>
	
		<input type="radio" name="op" value="1">Create<br><br>
		<input type="radio" name="op" value="2">Read<br><br>
		<input type="radio" name="op" value="3">Update<br><br>
		<input type="radio" name="op" value="4">Display<br><br>
		
		<input type="submit" name="submit" value="Submit"><br><br>
		
	</form>
	</body>
</html>


<?php

if(isset($_POST['submit']))
{
	$host = 'localhost';
	$username = 'root';
	$password = '';
	$database = 'teacher';
	
	$conn = mysqli_connect($host,$username,$password,$database) or die("Connection failed");

	$tid = $_POST['tid'];
	$tname = $_POST['tname'];
	$addr = $_POST['addr'];
	$sub = $_POST['sub'];
	
	$op = $_POST['op'];
	
	if($op==1)
	{
		mysqli_query($conn,"insert into teacher_master values($tid,'$tname','$addr','$sub')") or die("Error");
		echo "Record inserted successfully";
	}
	else if($op==2)
	{
		$row = mysqli_query($conn,"select * from teacher_master where tid=$tid");
		
		if($r = mysqli_fetch_array($row))
		{
			echo $r[0]."  ".$r[1]."  ".$r[2]."  ".$r[3]."<br>";
		}
		else
		{		
			echo "<br>Record not found";
		}
	}
	else if($op==3)
	{
		mysqli_query($conn,"update teacher_master set tname='$tname',address='$addr',subject='$sub' where tid=$tid");
		echo "<br>Record updated successfully";
	}
	else if($op==4)
	{
		$row = mysqli_query($conn,"select * from teacher_master");
		
		while($r = mysqli_fetch_array($row))
		{
			echo $r[0]."  ".$r[1]."  ".$r[2]."  ".$r[3]."<br>";
		}
	}
	
	mysqli_close($conn);
}
?>



/*CREATE TABLE teacher_master (
    tid INT PRIMARY KEY,
    tname VARCHAR(50),
    address VARCHAR(100),
    subject VARCHAR(50)
);*/
