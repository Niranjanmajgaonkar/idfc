   <?php
	$db = simplexml_load_file("Slip4_b.xml") or die("Error :: Cannot Open File");

	foreach($db->cricket as $c)
	{
		if($c->runs >= 1200 && $c->wicket >=50)	
		{
			echo $c->player."<br>";
			echo $c->runs."<br>";
			echo $c->wicket."<br>";
			echo $c->noofnotout."<br>";
		}
	}
?>