<?php
		class Calculator
		{	
			public $n1,$n2;
				
			public function __construct($n1,$n2)
			{
				$this->n1=$n1;
				$this->n2=$n2;
			}

			public function display()
			{
				echo "<br> Value of First number : ".$this->n1;
				echo "<br> Value of Second number : ".$this->n2;
				echo "<hr>";
			}
			public function add()
			{
				return $this->n1+$this->n2;	
			}
			
			public function sub()
			{
				return $this->n1-$this->n2;	
			}
			
			public function mult()
			{
				return $this->n1*$this->n2;
			}
			
			public function div()
			{
				return $this->n1/$this->n2;	
			}
		}
		$cal=new Calculator(3,4);
		$cal->display();
	
		echo "<br> Addition is : ".$cal->add();
		echo "<br> Subtraction is : ".$cal->sub();
		echo "<br> Multiplication is : ".$cal->mult();
		echo "<br> Division is : ".$cal->div();			
?>