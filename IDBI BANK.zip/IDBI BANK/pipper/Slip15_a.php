<html>
<body>
<form method="get" action="<?php echo $_SERVER['PHP_SELF'] ?>">
Subjects<br>
<select multiple name="sub[]">
<option value="C Language">C Language</option>
<option value="DBMS">DBMS</option>
<option value="Java">Java</option>
<option value="Python">Python</option>
</select>
<br>
<input type="submit" name="submit" value="submit">
</form>
</body>
</html>

<?php
	if(isset($_GET['submit']))
	{
		$sub = $_GET['sub'];

		if(count($sub)>0)
		{
			echo "<br>You have selected ".count($sub)." following subjects...";

			foreach($sub as $s)
			{
				echo "<br>$s";
			}
		}
		else
		{
			echo "<br>Please select subjects...";
		}

	}	
?>
