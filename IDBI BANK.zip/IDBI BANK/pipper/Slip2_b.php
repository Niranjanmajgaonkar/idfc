<?php
		$db = new DOMDocument();
		
		$db->load("student.xml");
		
		$db->save("student.doc");
		
		$x = $db->getElementsByTagName("stud");
		
		foreach($x as $s)
		{
				echo $s->textContent."<br>";
			
		}
		
?>