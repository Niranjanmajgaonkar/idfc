<?php
	if(isset($_POST['submit']))
	{
		$eid=$_POST['eid']; 
		$enm=$_POST['enm']; 
		$sal=$_POST['sal'];

		echo "<br> Employee ID : ".$eid;
		echo "<br> Employee Name : ".$enm;
		echo "<br> Employee Salary : ".$sal;
	}	
?>