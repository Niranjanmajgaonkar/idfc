<?php
		$fp = fopen("MyFile.dat","r");
		
		$contents = "";
		if($fp)
		{
			$contents = fread($fp,filesize("MyFile.dat"));
			fclose($fp);
		}
		else
		{
			$contents = "File Not Found";
		}
		
		echo $contents;
?>