<?php
		class Employee 
		{
				protected $id;
				protected $name;
				protected $department;
				protected $salary;

				public function __construct($id, $name, $department, $salary)
				{
						$this->id = $id;
						$this->name = $name;
						$this->department = $department;
						$this->salary = $salary;
				}
  
				public function getId() 
				{
						return $this->id;
				}

				public function getName() 
				{
						return $this->name;
				}

				public function getDepartment() 
				{
						return $this->department;
				}
		}

		class Manager extends Employee 
		{
				private $bonus;

				public function __construct($id, $name, $department, $salary, $bonus) 
				{
						$this->id = $id;
						$this->name = $name;
						$this->department = $department;
						$this->salary = $salary;
						$this->bonus = $bonus;
				}

				 public function getTotalSalary() 
				{
					return $this->salary + $this->bonus;
				}
		}

		// Create 3 Manager objects
		$m1 = new Manager(1, "John Doe", "Marketing", 50000, 10000);
		$m2 = new Manager(2, "Jane Smith", "Sales", 6000, 1000);
		$m3 = new Manager(3, "Mike Lee", "IT", 45000, 8000);

		// Find manager with maximum total salary
		$maxSalManager = null;
		$maxTotSal = 0;

		foreach ([$m1, $m2, $m3] as $manager) 
		{
				$totSal = $manager->getTotalSalary();
				if ($totSal > $maxTotSal) 
				{
						$maxTotSal = $totSal;
						$maxSalManager = $manager;
				}
		}

		if ($maxSalManager) {
		echo "<br>Manager with maximum total salary (salary + bonus): ";
		echo " <br> ID: " . $maxSalManager->getId() ;
		echo " <br> Name: " . $maxSalManager->getName() ;
		echo " <br> Department: " . $maxSalManager->getDepartment() ;
		echo " <br> Total Salary: $" . $maxTotSal ;
		} 
		else 
		{
				echo "No manager objects created.";
		}
?>