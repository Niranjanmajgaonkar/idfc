<html>
<body>
	<form action = "#" method = "get">
			Enter Number : <input type = "text" name = "num"><br><br>
			
			<input type = "submit" name = "submit" value = "Calculate"><br><br>
	</form>
</body>
</html>

<?php
		if(isset($_GET['submit']))
		{
			$num = $_GET['num'];
						
			function fibonacci($num)
			{
				if($num==0)
				{
					return 0;
				}
				else if($num==1)
				{
					return 1;
				}
				else
				{
					return (fibonacci($num-1)+fibonacci($num-2));
				}
			}
			
			echo "Fibonacci Series : ";
			for($i=0;$i<$num;$i++)
			{
				echo fibonacci($i)." ";
			}
			
			$n1=0;
			/* $n2=1;
			$n3=0;
			
			echo $n1."  ".$n2;
			
			while($num>2)
			{
				$n3 = $n1+$n2;
				
				echo " ".$n3;
				
				$n1 = $n2;
				$n2 = $n3;
			
				$num--;
			} */
			
			// Sum of digits
			
			$sum=0;
			while($num>0)
			{
				$sum = $sum + $num%10;
				$num = $num/10;
			}
			echo "<br> Sum of digits is : ".$sum;
		}
?>