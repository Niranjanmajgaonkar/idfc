<html>
<body>
	<form method = "get">
	Enter Radius : 
	<input type = "text" name = "r"><br>
	
	<input type = "radio" name = "op" value = "circum">Circumference<br>
	
	<input type = "radio" name = "op" value = "area"> Area<br>

	<input type = "Submit" name = "submit" value = "Submit"><br>
	</form>
</body>
</html>
<?php
	if(isset($_GET['submit']))
	{
		$r=$_GET['r'];
		$op=$_GET['op'];
		define("PI",3.14);
		class Circle
		{
			function circumference($r)
			{
				return 2*PI*$r;
			}
			function area($r)
			{
				return PI*$r*$r; 	
			}						
		}
		$cir=new Circle($r);
		
		if($op=="circum")
		{
			echo "<br> Circumference of Circle is : ".$cir->circumference($r);
		}
		else if($op=="area")
		{
			echo "<br> Area of Circle is : ".$cir->area($r);
		}
	}
?>