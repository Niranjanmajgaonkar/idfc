<?php
		$db = simplexml_load_file("Slip25_a_vehicle.xml") or die("ERROR :: File Cannot Open");
		
		$v = $db->addChild('vehicle');
		$v ->addAttribute('type','Four Wheeler');
		
		$p = $v->addChild('name','Thar');
		$r = $v->addChild('company','Mahindra');
		$w = $v->addChild('color','Black');
		$a = $v->addChild('average','500');
		
		header('content-Type:text/xml');
		echo $db->asXML();
?>