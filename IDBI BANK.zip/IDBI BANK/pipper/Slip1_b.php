<html>
<body>
	<form method = "get">
	Enter Course :
		<input type = "text" name = "co"><br><br>

	<input type = "submit" name = "submit" value = "submit"><br><br>
</body>
</html>

<?php
	if(isset($_GET['submit']))
	{
		$co=$_GET['co'];

		$xml = simplexml_load_file("student.xml") or die("Error::cannot open file");
	
		echo "<table border = 1>";
		
		echo "<th> Roll No </th>";
		echo "<th> Name </th>";
		echo "<th> Address </th>";
		echo "<th> College </th>";
		echo "<th> Course </th>";

		foreach($xml->stud as $s)
		{
			echo "<tr>";		
			if($s->course==$co)
			{
				echo "<td>$s->roll_no</td>";

				echo "<td>$s->name</td>";

				echo "<td>$s->address</td>";

				echo "<td>$s->college</td>";

				echo "<td>$s->course</td>";
			}
			echo "</tr>";
		}
	
		echo "</table>";
	}
?>