<?php
	$name = $_GET['name'];
	$age = $_GET['age'];
	$nat = $_GET['nat'];

	if(ctype_upper($name)===false)
	{
		echo "Name should be in upper case<br />";
	}
	if($age<18)
	{
		echo "Age should not be less than 18 years<br />";
	}
	if(strcasecmp($nat,"Indian")!=0)
	{
		echo "Nationality should be Indian<br />";
	}
?>