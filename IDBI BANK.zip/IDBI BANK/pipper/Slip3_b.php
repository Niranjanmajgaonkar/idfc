<?php
		$db = simplexml_load_file("Slip3_b.xml") or die("ERROR :: File Cannot Open");
		
		$t = $db->addChild('Team');
		$t ->addAttribute('country','India');
		
		$p = $t->addChild('player','.....');
		$r = $t->addChild('runs','.....');
		$w = $t->addChild('wicket','.....');
		
		header('content-Type:text/xml');
		echo $db->asXML();
?>