<html>
<head>
	<title>Distance Conversion</title>
</head>

<body>
	<form action = "<?php echo $_SERVER['PHP_SELF']; ?>" method = "POST">
	
	Enter Distance in meter :
		<input type = "text" name = "dist"><br><br>
		
		<input type = "radio" name = "op" value = "1">Meter to Centimeter<br><br>
		<input type = "radio" name = "op" value = "2">Meter to Kilometer<br><br>
		
		<input type = "submit" name = "submit" value = "Convert">
	</form>
</body>
</html>

<?php
	if(isset($_POST['submit']))
	{
			$dist = $_POST['dist'];
			$op = $_POST['op'];
	
			if($op==1)
			{
					echo "Conversion from meter to centimeter is : ";
		
					$cm = $dist*100;
					echo "$cm cm";
			}
			else if($op==2)
			{
					echo "Conversion from meter to Kilometer is : ";
			
					$km = $dist/1000;
					echo "$km km";
			}
	}
?>