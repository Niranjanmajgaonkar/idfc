<?php
	$pnm=$_GET['pnm'];
 
	$db = simplexml_load_file("player.xml") or die("Error :: Cannot Open File");

	foreach($db->pl as $p)
	{
		if($p->name==$pnm)	
		{
			echo $p->name."<br>";
			echo $p->country."<br>";
			echo $p->runs."<br>";
			echo $p->wickets."<br>";
		}
	}
?>