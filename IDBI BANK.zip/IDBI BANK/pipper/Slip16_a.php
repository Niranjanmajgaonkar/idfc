<html>
<head> 
	<title> Reverse String </title>
</head>
<body>
	<form method = "post" action = "<?php echo $_SERVER['PHP_SELF']; ?>">
	Enter String1 :
	<input type = "text" name="str1"><br><br>
	Enter String2 :
	<input type = "text" name="str2"><br><br>
	
	<input type = "submit" name = "submit" value = "Checked"><br><br>
	</form>
</body>
</html>
<?php
	if(isset($_POST['submit']))
	{
		$str1=$_POST['str1'];
		$str2=$_POST['str2'];

		if(strcmp($str1,$str2)==0)
		{
			echo "<br> Strings are Matched ";
		}
		else
		{
			echo "<br> Strings are not Matched ";
		}
	}
?>