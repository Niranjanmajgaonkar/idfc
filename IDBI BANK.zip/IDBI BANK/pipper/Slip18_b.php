<html>
<body>
	<form method = "get">
	Enter Publication :
		<input type = "text" name = "pub"><br><br>

	<input type = "submit" name = "submit" value = "submit"><br><br>
</body>
</html>

<?php
	if(isset($_GET['submit']))
	{
		$pub=$_GET['pub'];

		$db = simplexml_load_file("Slip18_b.xml") or die("Error::cannot open file");
	
		foreach($db->php as $p)
		{	
			if($p->publication==$pub)
			{
				echo $p->title."<br>";

				echo $p->publication."<br>";

				echo $p->price."<br>";
			}
		}
	}
?>