<html>
		<body>
			<form method = "post">
				Enter Number 1 : 
				<input type = "number" name = "n1"><br><br>
				Enter Number 2 : 
				<input type = "number" name = "n2"><br><br><br>
				
				<input type = "submit" name = "submit" value = "Submit">
			</form>
		</body>
</html>
<?php
	if(isset($_POST['submit']))
	{
			$n1 = $_POST['n1'];
			$n2 = $_POST['n2'];
			
	class calculator
	{
		public $n1,$n2;
		
		public function __construct($n1,$n2)
		{
			$this->n1=$n1;
			$this->n2=$n2;
		}
		public function add()
		{
			return $this->n1+$this->n2;
		}
		public function sub()
		{
			return $this->n1-$this->n2;
		}
		public function mult()
		{
			return $this->n1*$this->n2;
		}
		public function div()
		{
			return $this->n1/$this->n2;
		}
		
	}

	$cal = new calculator($n1,$n2);

	echo "<br>Addition is :".$cal->add();
	
	echo "<br>Subtraction is :".$cal->sub();
	
	echo "<br>Multiplication is :".$cal->mult();

	echo "<br>Division is :".$cal->div();
	
	}
?>